<?php

/**
 * Controller / Delete Canvas
 */

namespace Leantime\Domain\Obmcanvas\Controllers {

    /**
     *
     */
    class BoardDialog extends \Leantime\Domain\Canvas\Controllers\BoardDialog
    {
        protected const CANVAS_NAME = 'obm';
    }
}
