<?php

/**
 * Controller / Delete Canvas Item
 */

namespace Leantime\Domain\Obmcanvas\Controllers {

    /**
     *
     */
    class DelCanvasItem extends \Leantime\Domain\Canvas\Controllers\DelCanvasItem
    {
        protected const CANVAS_NAME = 'obm';
    }

}
