<?php

/**
 * Controller / Delete Canvas
 */

namespace Leantime\Domain\Minempathycanvas\Controllers {

    /**
     *
     */
    class BoardDialog extends \Leantime\Domain\Canvas\Controllers\BoardDialog
    {
        protected const CANVAS_NAME = 'minempathy';
    }
}
