<?php

/**
 * Controller / Delete Canvas Item
 */

namespace Leantime\Domain\Minempathycanvas\Controllers {

    /**
     *
     */
    class DelCanvasItem extends \Leantime\Domain\Canvas\Controllers\DelCanvasItem
    {
        protected const CANVAS_NAME = 'minempathy';
    }

}
