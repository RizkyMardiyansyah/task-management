<?php

/**
 * Controller / Edit Canvas Item
 */

namespace Leantime\Domain\Eacanvas\Controllers {

    /**
     *
     */
    class EditCanvasItem extends \Leantime\Domain\Canvas\Controllers\EditCanvasItem
    {
        protected const CANVAS_NAME = 'ea';
    }

}
