<?php

/**
 * Controller / Edit Comments
 */

namespace Leantime\Domain\Goalcanvas\Controllers {

    /**
     *
     */
    class EditCanvasComment extends \Leantime\Domain\Canvas\Controllers\EditCanvasComment
    {
        protected const CANVAS_NAME = 'goal';
    }

}
