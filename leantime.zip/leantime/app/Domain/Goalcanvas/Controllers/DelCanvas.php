<?php

/**
 * Controller / Delete Canvas
 */

namespace Leantime\Domain\Goalcanvas\Controllers {

    /**
     *
     */
    class DelCanvas extends \Leantime\Domain\Canvas\Controllers\DelCanvas
    {
        protected const CANVAS_NAME = 'goal';
    }
}
