<?php

/**
 * Controller / Delete Canvas
 */

namespace Leantime\Domain\Emcanvas\Controllers {

    /**
     *
     */
    class BoardDialog extends \Leantime\Domain\Canvas\Controllers\BoardDialog
    {
        protected const CANVAS_NAME = 'em';
    }
}
