<?php

/**
 * - sqcanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class Sqcanvas extends Canvas
    {
        protected const CANVAS_NAME = 'sq';
    }
}
