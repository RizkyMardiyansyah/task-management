<?php

/**
 * - obmcanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class Obmcanvas extends Canvas
    {
        protected const CANVAS_NAME = 'obm';
    }
}
