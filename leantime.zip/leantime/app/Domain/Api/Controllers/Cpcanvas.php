<?php

/**
 * - cpcanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers;

/**
 *
 */
class Cpcanvas extends Canvas
{
    protected const CANVAS_NAME = 'cp';
}
