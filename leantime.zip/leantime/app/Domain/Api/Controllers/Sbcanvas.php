<?php

/**
 * - sbcanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class Sbcanvas extends Canvas
    {
        protected const CANVAS_NAME = 'sb';
    }
}
