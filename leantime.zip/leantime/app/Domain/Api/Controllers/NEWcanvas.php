<?php

/**
 * - NEWcanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class NEWcanvas extends Canvas
    {
        protected const CANVAS_NAME = 'NEW';
    }
}
