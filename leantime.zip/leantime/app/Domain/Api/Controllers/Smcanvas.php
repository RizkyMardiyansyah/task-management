<?php

/**
 * - smcanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class Smcanvas extends Canvas
    {
        protected const CANVAS_NAME = 'sm';
    }
}
