<?php

/**
 * - smcanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers;

/**
 *
 */
class Goalcanvas extends Canvas
{
    protected const CANVAS_NAME = 'goal';
}
