<?php

/**
 * - eacanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers;

/**
 *
 */
class Eacanvas extends Canvas
{
    protected const CANVAS_NAME = 'ea';
}

