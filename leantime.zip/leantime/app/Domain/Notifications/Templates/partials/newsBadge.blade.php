@if($hasNews)
    <span class='notificationCounter'>!</span>
@endif
