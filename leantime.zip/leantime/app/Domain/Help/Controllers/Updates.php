<?php

namespace Leantime\Domain\Help\Controllers {

    use Leantime\Core\Controller;

    /**
     *
     */
    class Updates extends Controller
    {
        /**
         * get - handle get requests
         *
         * @access public
         *
         */
        public function get($params)
        {
        }

        /**
         * post - handle post requests
         *
         * @access public
         *
         */
        public function post($params)
        {
        }

        /**
         * put - handle put requests
         *
         * @access public
         *
         */
        public function put($params)
        {
        }

        /**
         * delete - handle delete requests
         *
         * @access public
         *
         */
        public function delete($params)
        {
        }
    }

}
