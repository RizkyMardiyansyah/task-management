<?php

/**
 * Controller / Delete Canvas Item
 */

namespace Leantime\Domain\Lbmcanvas\Controllers {

    /**
     *
     */
    class DelCanvasItem extends \Leantime\Domain\Canvas\Controllers\DelCanvasItem
    {
        protected const CANVAS_NAME = 'lbm';
    }

}
