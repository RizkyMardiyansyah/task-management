<?php

/**
 * Controller / Edit Canvas Item
 */

namespace Leantime\Domain\Lbmcanvas\Controllers {

    /**
     *
     */
    class EditCanvasItem extends \Leantime\Domain\Canvas\Controllers\EditCanvasItem
    {
        protected const CANVAS_NAME = 'lbm';
    }

}
