<?php

/**
 * Controller / Delete Canvas Item
 */

namespace Leantime\Domain\Cpcanvas\Controllers {

    /**
     *
     */
    class DelCanvasItem extends \Leantime\Domain\Canvas\Controllers\DelCanvasItem
    {
        protected const CANVAS_NAME = 'cp';
    }

}
