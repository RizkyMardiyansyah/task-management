<?php

/**
 * Controller / Edit Comments
 */

namespace Leantime\Domain\Cpcanvas\Controllers {

    /**
     *
     */
    class EditCanvasComment extends \Leantime\Domain\Canvas\Controllers\EditCanvasComment
    {
        protected const CANVAS_NAME = 'cp';
    }

}
