<?php

/**
 * Controller / Delete Canvas
 */

namespace Leantime\Domain\Cpcanvas\Controllers {

    /**
     *
     */
    class BoardDialog extends \Leantime\Domain\Canvas\Controllers\BoardDialog
    {
        protected const CANVAS_NAME = 'cp';
    }
}
