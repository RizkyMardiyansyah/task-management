<?php

/**
 * Controller / Edit Comments
 */

namespace Leantime\Domain\Dbmcanvas\Controllers {

    /**
     *
     */
    class EditCanvasComment extends \Leantime\Domain\Canvas\Controllers\EditCanvasComment
    {
        protected const CANVAS_NAME = 'dbm';
    }

}
