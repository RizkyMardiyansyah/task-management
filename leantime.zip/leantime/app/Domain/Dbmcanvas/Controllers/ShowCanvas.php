<?php

/**
 * Controller
 */

namespace Leantime\Domain\Dbmcanvas\Controllers {

    /**
     *
     */
    class ShowCanvas extends \Leantime\Domain\Canvas\Controllers\ShowCanvas
    {
        protected const CANVAS_NAME = 'dbm';
    }

}
