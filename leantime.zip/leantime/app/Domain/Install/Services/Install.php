<?php

namespace Leantime\Domain\Install\Services {

    /**
     *
     */
    class Install
    {
    }
}
