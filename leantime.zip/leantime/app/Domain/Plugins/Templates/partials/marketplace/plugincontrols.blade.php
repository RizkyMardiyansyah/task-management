<div class="tw-flex tw-justify-between tw-items-center tw-gap-base">
    <x-global::button type="primary" link="#/plugins/details/{{ $plugin->identifier }}">
        {{ __('marketplace.details_link') }}
    </x-global::button>
</div>
