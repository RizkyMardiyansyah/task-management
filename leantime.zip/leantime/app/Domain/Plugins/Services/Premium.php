<?php

namespace Leantime\Domain\Plugins\Services;

class Premium
{
    //
}
