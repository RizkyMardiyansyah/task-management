<?php

/**
 * Controller / Delete Canvas Item
 */

namespace Leantime\Domain\Insightscanvas\Controllers {

    /**
     *
     */
    class DelCanvasItem extends \Leantime\Domain\Canvas\Controllers\DelCanvasItem
    {
        protected const CANVAS_NAME = 'insights';
    }

}
