<?php

/**
 * XML export
 */

namespace Leantime\Domain\Insightscanvas\Controllers {

    /**
     *
     */
    class Export extends \Leantime\Domain\Canvas\Controllers\Export
    {
        protected const CANVAS_NAME = 'insights';
    }
}
