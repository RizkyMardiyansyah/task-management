<?php

namespace Leantime\Core;

class CliRequest extends IncomingRequest
{
    //
}
