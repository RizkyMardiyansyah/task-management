<?php

namespace Leantime\Core\Providers;

use Illuminate\Support\ServiceProvider;

class Cache extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
    }

    /**
     * Manages the instance cache.
     *
     * @return void
     */
    private function instanceCacheManager()
    {
    }
}
